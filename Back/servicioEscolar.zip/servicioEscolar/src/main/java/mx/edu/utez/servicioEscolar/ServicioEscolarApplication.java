package mx.edu.utez.servicioEscolar;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServicioEscolarApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServicioEscolarApplication.class, args);
	}

}
